# Generates credentials needed to test out the provider/appserver with test_mule.py

import util

util.gen_keypair('sensor')
util.gen_keys() # appserver credentials