# galaxy
Privacy Preserving Data Mule System

1. To generate sensor data that can then be sampled, run the following


```bash
python generate_data.py <size_in_bytes_of_each_sample> <number_of_samples>
```

This will generate `data.h` which has a 2D array called `data`. 
