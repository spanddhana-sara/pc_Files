Blink App
=========

Blink an LED. Make sure to set the correct pin in the app.

AES
===

1. Make sure `nrfcrypto` is in path and can be included. 
2. To make `gcc -o aes-main-test.out aes-main-test.c aes_gcm.c -lnrf_crypto`

